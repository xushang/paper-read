
% run three demos

% Shows one-dimensional Huber function and MC penalty
huber_1d_demo

% Shows generalized Huber function and generalized MC penalty in two-dimensions
huber_2d_demo

% Signal denoising (Example 1 from paper)
GMC_demo

