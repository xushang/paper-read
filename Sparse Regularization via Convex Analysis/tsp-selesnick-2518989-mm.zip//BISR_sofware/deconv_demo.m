%% deconv_demo
% Demo of sparse deconvolution with deconv_BISR

%%

clear
close all

rmse = @(err) sqrt(mean(abs(err).^2));

%% Load filter

EXAMPLE_NUMBER = 2;   % 1 or 2

[h, p] = deconv_demo_impulse_response(EXAMPLE_NUMBER);

% Verify that P(om) <= |H(om)|^2

f = (0:100)/200;
om = 2 * pi * f;
z = exp(1i * om);
freqresp = @(h) polyval(h, z);

H = freqresp(h);
P = freqresp(p);

figure(1)
clf
plot(om, abs(H).^2, om, abs(P))
legend('|H(\omega)|^2', 'P(\omega)')
xlabel('Frequency (\omega)')
xlim([0 pi])
ylim([0 1.2])


%% Create data

rng(1);   % To reset random number generator

N = 100;
x = sparse_signal;
hx = conv(h, x);

sigma = 4;
noise = sigma * randn(size(hx));

y = hx + noise;

%% Display plots

ylim1 = [-1 1]*150;

figure(2)
clf
subplot(2,2,1)
plot(x)
title('Sparse signal');
ylim(ylim1);

subplot(2,2,2)
plot(0:length(h)-1, h)
title('Impulse response h(n)');

subplot(2,2,3)
plot(hx)
title('Convolution');
ax2 = axis;

subplot(2,2,4)
plot(y)
title('Convolution plus noise');
axis(ax2)

%% Deconvolution

beta = 2.5;
lam = beta * sigma * sqrt(sum(abs(h).^2));

p0 = p(2);
p1 = p(3);
gamma = [p0+2*p1, p0-2*p1];

pen = 'atan';   % Type of penalty function

Nit = 50;       % Number of iteration

% BISR Deconvolution
[x_BISR, cost_BISR] = deconv_BISR(y, h, lam, Nit, gamma, pen);

% L1 Deconvolution (for comparison)
[x_L1, cost_L1] = deconv_L1(y, h, lam, Nit);

rmse_BISR = rmse(x - x_BISR);
rmse_L1 = rmse(x - x_L1);

fprintf('RMSE = %.2f (L1 norm deconv) \n', rmse_L1)
fprintf('RMSE = %.2f (BISR deconv) \n', rmse_BISR)

%% Cost function history

figure(3)
clf
plot(1:Nit, cost_BISR, 'k.-')
xlabel('Iteration')
title('Cost function history')
zoom yon

%% Plot result

n = 1:N;
k = abs(x) > 1e-10;

figure(4)
clf
plot(n(k), x(k), 'o', n, x_BISR, '-')
legend('True', 'BISR deconvolution')

%% Compare L1 and BISR

err_L1 = abs(x - x_L1);
err_BISR = abs(x - x_BISR);

figure(5)
clf
plot(err_L1, err_BISR, 'o', [0, 30], [0, 30])
title('Deconvolution error')
xlabel('L1 norm')
ylabel('BISR')
axis square

print -dpdf figures/deconv_demo

%% Miscellaneous

% BISR, version 2 (automatic stopping condition)
[x_BISR2, Nit2] = deconv_BISR_v2(y, h, lam, gamma, pen);
rmse_BISR2 = rmse(x - x_BISR2);
fprintf('RMSE = %.2f (BISR deconv, %d iterations) \n', rmse_BISR2, Nit2)


% Verify that BISR with a = (0, 0) agrees with L1 deconvolution:
x_00 = deconv_BISR(y, h, lam, Nit, [0, 0], pen);
L1_check = max(abs( x_L1 - x_00 ));
fprintf('The difference between L1 and BISR with a = (0,0) is %f\n', L1_check)

%%

% Reference:
% Enhanced Sparsity by Non-Separable Regularization
% Ivan Selesnick and Ilker Bayram
% IEEE Transactions on Signal Processing, 2016

