function [x, cost] = deconv_L1(y, h, lam, Nit)
% [x, cost] = deconv_L1(y, h, lam, Nit)
% Sparse deconvolution by L1 norm minimization
% Algorithm: iterative thresholding (Forward Backward Splitting).
% Cost function:
%    F(x) = 0.5 sum(abs(y-conv(h,x)).^2) + + lam * sum(abs(x))
%
% INPUT
%   y - noisy data
%   h - filter impulse response
%   lam - regularization parameter
%   Nit - number of iterations
%
% OUTPUT
%   x - deconvolved sparse signal
%   cost - cost function history

% Ivan Selesnick, selesi@nyu.edu, 2014

y = y(:);                                       % convert to column vector
cost = zeros(1, Nit);                           % cost function history
N = length(y);
L = N - length(h) + 1;

soft = @(t, T) max(t - T, 0) + min(t + T, 0);

H = sparse( convmtx(h(:), L) );

rho = max(eig(H'*H));  
% Or use maximum value of |H(om)|^2

mu = 1.9 / rho;       % mu : step size

HTy = H' * y;           % H'*y
x = HTy;                % initialization

for k = 1:Nit   
    z = x - mu * (H'*(H*x) - HTy);
    x = soft(z, lam * mu);
    cost(k) = 0.5*sum(abs(y-H*x).^2) + lam*sum(abs(x));  % cost function value
end
