function [x, cost, vopt] = deconv_BISR(y, h, lam, Nit, gamma, pen)
% [x, cost, vopt] = deconv_BISR(y, h, lam, Nit, gamma, pen)
% Sparse deconvolution by bivariate sparse (non-convex) regularization
%
% Cost function:
%    F(x) = 0.5 sum(abs(y-conv(h,x)).^2) + lam/2 sum_n(psi(x(n-1),x(n)))
%
% INPUT
%   y - noisy data
%   h - filter impulse response
%   lam - regularization parameter
%   Nit - number of iterations
%   gamma - eigenvalues of 2x2 matrix
%   pen - penalty ('log' | 'atan' | 'rat')
%
% OUTPUT
%   x - estimate of input signal
%   cost - cost function history
%   vopt - verification of optimality
%              (x(n), vopt(n)) should lie on graph of sign function

% Algorithm: iterative thresholding (Forward Backward Splitting).

% Ivan Selesnick, selesi@nyu.edu, 2014
% Revised May 2015.

% Reference:
% Enhanced Sparsity by Non-Separable Regularization
% Ivan Selesnick and Ilker Bayram
% IEEE Transactions on Signal Processing, 2016

soft = @(t, T) max(t - T, 0) + min(t + T, 0);

y = y(:);                                       % convert to column vector
cost = zeros(1, Nit);                           % cost function history
N = length(y);
L = N - length(h) + 1;

H = sparse( convmtx(h(:), L) );

rho = max(eig(H'*H));  
% or use maximum value of |H(om)|^2

mu = 1.9 / rho;             % mu : step size

a = gamma / lam;

HTy = H' * y;               % H'*y

% Initialization
x = HTy;

for k = 1:Nit
    
    [s1, s2] = S_grad(a, x(1:end-1), x(2:end), pen);
    w = ([s1; 0] + [0; s2])/2;
    
    z = x - mu * (H'*(H*x) - HTy + lam * w);
    x = soft(z, mu * lam);

    % cost function history
    cost(k) = 0.5 * sum(abs(y-H*x).^2) + lam/2 * sum(psi2(a, [0; x], [x; 0], pen));
    
    % Set to true or false to display plots
    if false
        % Optimality scatter plot
        [s1, s2] = S_grad(a, x(1:end-1), x(2:end), pen);
        w = ([s1; 0] + [0; s2])/2;
        v = 1/lam * H'*(y - H*x) - w;
        
        figure(5)
        clf
        M = 1.5*max(abs(x));
        line([-M 0 0 M], [-1 -1 1 1], 'color', [1 1 1]*0.8, 'linewidth', 2)
        hold on
        plot(x, v, '.', 'markersize', 10)
        hold off
        xlim([-M M])
        ylim([-1.5 1.5])
        title(sprintf('Iteration %d', k))
        drawnow
    end
    
end

[s1, s2] = S_grad(a, x(1:end-1), x(2:end), pen);
w = ([s1; 0] + [0; s2])/2;
vopt = 1/lam * H'*(y - H*x) - w;
