function d2S = S_hessian(a, x1, x2, pen)

% d2S = S_hessian(a, x1, x2, pen)
%
% Hessian of concave S function
%
% INPUT
%   a : 2-element vector (positive, real) with a(1) > 0, a(2) > 0
%   x1, x2 : scalars
%   pen : 'log' or 'atan' or 'rat'

% Ivan Selesnick, selesi@nyu.edu, June, 2015

% Reference:
% Enhanced Sparsity by Non-Separable Regularization
% Ivan Selesnick and Ilker Bayram
% IEEE Transactions on Signal Processing, 2016


if nargin < 4
    % Default penalty
    pen = 'log';
end

[phi, dphi, d2phi] = penalty(pen);

% s = @(x, a) phi(x, a) - abs(x);
% ds = @(x, a) dphi(x, a) - sign(x);
d2s = @(x, a) d2phi(x, a);

a1 = a(1);
a2 = a(2);

alpha = (a1 + a2)/2;
r = (a1 - a2)/(a1 + a2);

if (a1 == 0) && (a2 == 0)
    
    d2S = zeros(2);
    
else
    
    % Areas 1-4
    k1 = x2 .* (x1 - x2) >= 0;
    k2 = x1 .* (x2 - x1) >= 0;
    k3 = -x1 .* (x2 + x1) >= 0;
    k4 = -x2 .* (x2 + x1) >= 0;
    
    if k1
        k = 1;
    elseif k2
        k = 2;
    elseif k3
        k = 3;
    elseif k4
        k = 4;
    else
        error('?')
    end
    
    switch k
        case 1
            f = x1 + r*x2;
            v = [1 r];
            v2 = [0 1];
            g = (1+r)*x2;
        case 2
            f = r*x1 + x2;
            v = [r 1];
            v2 = [1 0];
            g = (1+r)*x1;
        case 3
            f = r*x1 + x2;
            v = [r 1];
            v2 = [1 0];
            g = (1-r)*x1;
        case 4
            f = x1 + r*x2;
            v = [1 r];
            v2 = [0 1];
            g = (1-r)*x2;
    end
    
    d2S = d2s(f , alpha) * (v'*v) + (1-r^2) * d2s(g , alpha) * diag(v2);
    
end
