
% plot_ellipses.m

% Ivan Selesnick, selesi@nyu.edu, 2015

clear all

% Set penalty
pen = 'atan';
pen = 'rat';
pen = 'log';

% Set 'a' parameters
a = [1.5 0.3];

Q = [1 1; 1 -1]/sqrt(2);
K = Q * diag(a) * Q';
e_K = pd2ellipse(K);

color1 = 'blue';
color2 = 'red';

figure(1)
clf
x = -8:2:8;
for x1 = x
    for x2 = x        
        d2S = S_hessian(a, x1, x2, pen);
        e = pd2ellipse(-d2S);       
        plot(x1 + e(1,:), x2 + e(2,:), 'color', color2)
        hold on
        plot(x1 + e_K(1,:), x2 + e_K(2,:), 'color', color1)
    end
end
hold off
daspect([1 1 1])
axis([-1 1 -1 1]*8)
title(sprintf('Hessian ellipses with %s penalty and a = (%.1f, %.1f)', pen, a(1), a(2)))
xlabel('x_1')
ylabel('x_2')

print -dpdf figures/ellipses

%%

% Reference:
% Enhanced Sparsity by Non-Separable Regularization
% Ivan Selesnick and Ilker Bayram
% IEEE Transactions on Signal Processing, 2016
