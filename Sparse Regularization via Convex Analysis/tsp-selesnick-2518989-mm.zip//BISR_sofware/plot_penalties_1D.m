
% plot_penalties_1D

% pen = 'atan';
pen = 'log';

phi = penalty(pen);

x = 4 * (-50:50)/50;

a1 = 0.0;
a2 = 0.2;
a3 = 0.6;
a4 = 1.5;

% a2 = 0.2;
% a3 = 0.5;
% a4 = 1.0;

figure(1)
clf

plot(x, phi(x, a1), x, phi(x, a2), x, phi(x, a3), x, phi(x, a4))

x1 = 3;
text(x1, phi(x1, a1), sprintf('a = %.1f', a1) ) 
text(x1, phi(x1, a2), sprintf('a = %.1f', a2) ) 
text(x1, phi(x1, a3), sprintf('a = %.1f', a3) ) 
text(x1, phi(x1, a4), sprintf('a = %.1f', a4) ) 

title('Penalty function, \phi(t; a)')
xlabel('t')

set(gca, 'ytick', 0:4)

daspect([1 1 1])

print -dpdf figures/penalties_1D

%%

% Reference:
% Enhanced Sparsity by Non-Separable Regularization
% Ivan Selesnick and Ilker Bayram
% IEEE Transactions on Signal Processing, 2016


