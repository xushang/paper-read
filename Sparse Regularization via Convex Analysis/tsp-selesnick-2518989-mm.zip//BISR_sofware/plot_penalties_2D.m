
% plot_penalties_2D

pen = 'atan';

[phi, dphi, d2phi] = penalty(pen);

a = [1.2 0.3];   % 'a' parameters

amin = a(1);
amax = a(2);

N = 25;
xmax = 2;
x1 = linspace(-xmax, xmax, N);
x2 = x1;
[X1, X2] = meshgrid(x1, x2);

myview = @() view([20 10]);


%% L1 norm

P = abs(X1) + abs(X2);

figure(1)
clf

subplot(2, 1, 1)
mesh(x1, x2, P, 'edgecolor', 'black');
title('Separable convex penalty (L1 norm)');
myview()
daspect([1 1 1])

subplot(2, 1, 2)
contour(x1, x2, P, 20, 'edgecolor', 'black')
axis square
title('Contours')

orient tall
print -dpdf figures/functions_2D_fig1


%% Separable non-convex penalty

P = phi(X1, amax) + phi(X2, amax);

figure(2)
clf

subplot(2, 1, 1)
mesh(x1, x2, P, 'edgecolor', 'black');
title('Separable non-convex penalty');
myview()
zlim([0 2*xmax])
daspect([1 1 1])

subplot(2, 1, 2)
contour(x1, x2, P, 20, 'edgecolor', 'black')
axis square
title('Contours')

orient tall
print -dpdf figures/functions_2D_fig2


%% Non-separable non-convex penalty

P = psi2(a, X1, X2, pen);

figure(3)
clf

subplot(2, 1, 1)
mesh(x1, x2, P, 'edgecolor', 'black');
title('Non-separable non-convex penalty');
myview()
zlim([0 2*xmax])
daspect([1 1 1])

subplot(2, 1, 2)
contour(x1, x2, P, 20, 'edgecolor', 'black')
axis square
title('Contours')

orient tall
print -dpdf figures/functions_2D_fig3


%% Display S(x) = psi(x) - ||x||_1

S = P - abs(X1) - abs(X2);

figure(4)
clf

subplot(2, 1, 1)
mesh(x1, x2, S, 'edgecolor', 'black');
title('Smooth concave function S(x)');
myview()
zlim([0 2*xmax]-xmax*1.5)
daspect([1 1 1])

subplot(2, 1, 2)
contour(x1, x2, S, 20, 'edgecolor', 'black')
axis square
title('Contours')

orient tall
print -dpdf figures/functions_2D_fig4


%% Bounds
% The non-separable penalty is bounded by the 
% separable penalties corresponding to the two 'a' parameters.

figure(5)
clf

P_max = phi(X1, amax) + phi(X2, amax);
P_min = phi(X1, amin) + phi(X2, amin);

GRAY = [1 1 1]*0.6;

mesh(x1, x2, P, 'edgecolor', GRAY);
hold on
mesh(x1, x2, P_max, 'edgecolor', 'k')
mesh(x1, x2, P_min, 'edgecolor', 'k')
% daspect([1 1 1])
myview()
zlim([0 3])

print -dpdf figures/functions_2D_fig5

%%

% Reference:
% Enhanced Sparsity by Non-Separable Regularization
% Ivan Selesnick and Ilker Bayram
% IEEE Transactions on Signal Processing, 2016

