function [h, p] = deconv_demo_impulse_response(EXAMPLE_NUMBER)
% [h, p] = deconv_demo_impulse_response(EXAMPLE_NUMBER)
% EXAMPLE_NUMBER = 1 or 2
% FIR impulse response for examples.

switch EXAMPLE_NUMBER
    case 1
        
        h = [
            0.4482
            -0.1026
            0.1597
            0.3788
            0.3029
            0.0571
            -0.1357
            -0.1629
            -0.0659
            0.0424
            0.0821
            0.0501
            -0.0054
            -0.0372
            -0.0315
            -0.0058
            0.0147
            0.0175
            0.0071
            -0.0045
            -0.0088
            ]';
        h = h / sum(h);
        
        p = 0.1*[1 4 1];

    case 2
        
        h = [
            0.2380
            -0.0426
            -0.2293
            0.2469
            0.3920
            0.3230
            0.1738
            0.0385
            -0.0415
            -0.0659
            -0.0330
            ]';
        h = h / sum(h);
        C = 0.19;

        p = C*[1 2 1];

end


