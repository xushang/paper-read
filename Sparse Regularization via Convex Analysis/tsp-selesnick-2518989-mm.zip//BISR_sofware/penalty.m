function [phi, dphi, d2phi] = penalty(pen)

% [phi, dphi, d2phi] = penalty(pen)
%
% pen = 'log' or 'atan' or 'rat'
%
% OUTPUT
%  function handles for:
%  phi - penalty function phi(x, a)  ['a' should be non-negative scalar]
%  dphi - derivative of phi
%  d2phi - second derivative of phi

% Reference:
% Enhanced Sparsity by Non-Separable Regularization
% Ivan Selesnick and Ilker Bayram
% IEEE Transactions on Signal Processing, 2016

switch pen
    
    case 'log'
        
        % phi = @(x, a) (1/a) * log(1 + a * abs(x));   % for a > 0
        % phi = @(x, a) abs(x); % for a = 0
        
        % To allow both a > 0 and a = 0, use alternate code:
        phi = @(x, a) ( (a>0)*log1p(a*abs(x)) + (a==0)*abs(x)) / ( (a>0)*a + (a==0)*1 ) ;
        % Note: log1p is defined log1p(x) = log(1 + x)
        
        dphi = @(x, a) sign(x)./(1 + a * abs(x));      % derivative of phi
        d2phi = @(x, a) -a ./((1 + a * abs(x)).^2);    % 2nd derivative of phi
        
    case 'atan'
        
        % phi = @(x, a) 2./(a*sqrt(3)) .* (atan((2*a.*abs(x)+1)/sqrt(3)) - pi/6); % for a > 0
        % phi = @(x, a) abs(x); % for a = 0
        
        % To allow a = 0, use alternate code:
        phi = @(x, a) ( (a>0)*2*(atan((2*a.*abs(x)+1)/sqrt(3))-pi/6) + (a==0)*abs(x) ) / ((a>0)*a*sqrt(3) + (a==0)*1);
        
        dphi = @(x, a) sign(x) ./ (1 + a*abs(x) + (a*x).^2) ;
        %         dphi = @(x, a) sign(x) ./ ( (1 + a*abs(x)).*(a*abs(x)) + 1) ;
        d2phi = @(x, a) -(2*abs(x)*a^2 + a)./((1 + a * abs(x) + a^2 * x.^2).^2);
        
    case 'rat'
        
        phi = @(x, a) abs(x) ./ (1 + (a/2) * abs(x));
        dphi = @(x, a) -(a/2)*x ./ ((a/2)*abs(x) + 1).^2  + sign(x)./((a/2)*abs(x) + 1);
        d2phi = @(x, a) (a^2/2)*abs(x) ./ (((a/2)*abs(x) + 1).^3) - a./((a/2)*abs(x) + 1).^2;
        
end

