function p = psi2(a, x1, x2, pen)

% p = psi2(a, x1, x2, pen)
% Non-separable bivariate penalty function
%
% INPUT
%   a : 2-element vector with a(i) >= 0
%   x1, x2 : arrays of equal size
%   pen : 'log' or 'atan' or 'rat'
%
% EXAMPLE
%  x = linspace(-2, 2, 25);
%  [X1, X2] = meshgrid(x, x);
%  a = [1.2 0.4];
%  P = psi2(a, X1, X2, 'log');
%  figure(1), clf
%  mesh(x, x, P, 'edgecolor', 'black');

% Ivan Selesnick, selesi@nyu.edu, June, 2014
% Revised May 2015

% Reference:
% Enhanced Sparsity by Non-Separable Regularization
% Ivan Selesnick and Ilker Bayram
% IEEE Transactions on Signal Processing, 2016

phi = penalty(pen);

a1 = a(1);
a2 = a(2);

L1 = @(x1, x2) abs(x1) + abs(x2);

PA = phi( a1*abs(x1+x2) + a2*abs(x1-x2), 1/2);
PB = a2 * phi( L1(x1, x2) - abs(x1-x2), a1/2);
PC = a1 * phi( L1(x1, x2) - abs(x1+x2), a2/2);
p = (PA + PB + PC) / (a1+a2);

