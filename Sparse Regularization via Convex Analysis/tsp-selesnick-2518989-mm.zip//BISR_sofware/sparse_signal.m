function x = sparse_signal()

% x = sparse_signal()
% Make a random sparse signal of length 100
%
% Signal length: 100
% Number of non-zeros values: 10
% Non-zero values are uniformly distributed between -100 and 100.

N = 100;

k = randperm(N);
k = k(1:10);
x = zeros(N, 1);
x(k) = 100 * (2*rand(10, 1)-1);
