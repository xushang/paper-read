
Bivariate sparse regularization (BISR)

This folder contains MATLAB software to accompany the paper
'Enhanced Sparsity by Non-Separable Regularization',
I. W. Selesnick and I. Bayram,
IEEE Transactions on Signal Processing, 2016.

---

List of programs

 plot_functions_1D.m   Make plots as shown in the paper plot_penalties_1D.m plot_penalties_2D.m plot_ellipses.m penalty.m          Univariate penalty function psi2.m             Bivariate penalty function S_grad.m           Gradient of concave function S S_hessian.m        Hessian of concave function S
 pd2ellipse.m       Ellipse corresponding to a
                        positive definite matrix

 deconv_BISR.m      Sparse deconvolution using BISR deconv_BISR_v2.m   Self-contained implementation
 deconv_L1.m        Sparse deconvolution using L1 norm deconv_demo.m      Demo of deconvolution (Examples 1 and 2)
 sparse_signal.m    Generate sparse signal for demo
 deconv_demo_impulse_response.m  Impulse responses for demo 
---

Contact Information:
Ivan Selesnick (Email: selesi@nyu.edu)
Department of Electrical and Computer Engineering
Tandon School of Engineering
New York University
6 Metrotech Center
Brooklyn, NY 11201, USA

---

Last edit: January 16, 2016
