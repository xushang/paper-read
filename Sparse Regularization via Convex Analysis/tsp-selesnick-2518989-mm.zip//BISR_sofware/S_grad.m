function [S1, S2] = S_grad(a, x1, x2, pen)

% [S1, S2] = S_grad(a, x1, x2, pen)
%
% Gradient of concave function S.
%
% a : 2-element vector (positive, real) with a(1) >= 0 a(2) >= 0
% x1, x2 : arrays of equal size
% pen : 'log' or 'atan' or 'rat'
%
% EXAMPLE
%   x = linspace(-2, 2, 25);
%   [X1, X2] = meshgrid(x, x);
%   a = [1.2 0.4];
%   [S1, S2] = S_grad(a, X1, X2, 'log');
%   figure(10), clf
%   mesh(x, x, S1, 'edgecolor', 'black');
%   view([20 20])

% Ivan Selesnick, selesi@poly.edu, June, 2014
% Revised May 2015

% Reference:
% Enhanced Sparsity by Non-Separable Regularization
% Ivan Selesnick and Ilker Bayram
% IEEE Transactions on Signal Processing, 2016

[phi, dphi, d2phi] = penalty(pen);

% s = @(x, a) phi(x, a) - abs(x);
ds = @(x, a) dphi(x, a) - sign(x);

a1 = a(1);
a2 = a(2);

alpha = (a1 + a2)/2;
r = (a1 - a2)/(a1 + a2);

if (a1 == 0) && (a2 == 0)
    
    S1 = zeros(size(x1));
    S2 = zeros(size(x1));
    
else
    
    % Areas 1-4
    k1 = x2 .* (x1 - x2) >= 0;
    k2 = x1 .* (x2 - x1) >= 0;
    k3 = -x1 .* (x2 + x1) >= 0;
    k4 = -x2 .* (x2 + x1) >= 0;
    
    S1_1 = @(x1, x2) ds( x1 + r*x2 , alpha );
    S1_2 = @(x1, x2) r * ds( r * x1 + x2 , alpha ) + (1 - r) * ds( x1 , a1 );
    S1_3 = @(x1, x2) r * ds( r * x1 + x2 , alpha ) + (1 + r) * ds( x1 , a2 );
    S1_4 = @(x1, x2) ds( x1 + r*x2 , alpha );
    
    S2_1 = @(x1, x2) r * ds( x1 + r*x2 , alpha ) + (1 - r) * ds( x2 , a1 );
    S2_2 = @(x1, x2) ds( r * x1 + x2 , alpha );
    S2_3 = @(x1, x2) ds( r * x1 + x2 , alpha );
    S2_4 = @(x1, x2) r * ds( x1 + r*x2 , alpha ) + (1 + r) * ds( x2 , a2 );
    
    S1 = nan(size(x1));
    S1(k1) = S1_1(x1(k1), x2(k1));
    S1(k2) = S1_2(x1(k2), x2(k2));
    S1(k3) = S1_3(x1(k3), x2(k3));
    S1(k4) = S1_4(x1(k4), x2(k4));
    
    S2 = nan(size(x1));
    S2(k1) = S2_1(x1(k1), x2(k1));
    S2(k2) = S2_2(x1(k2), x2(k2));
    S2(k3) = S2_3(x1(k3), x2(k3));
    S2(k4) = S2_4(x1(k4), x2(k4));
    
end
