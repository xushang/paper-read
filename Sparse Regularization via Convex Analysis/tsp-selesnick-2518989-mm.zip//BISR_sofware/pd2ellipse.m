function e = pd2ellipse(A)

% e = pd2ellipse(A)
% Convert a positive definite matrix to an ellipse
% 
% INPUT
%   A : positive definite matrix (2 x 2)
% OUPUT
%   e : ellipse, i.e., plot(e(1,:), e(2,:)) shows the ellipse of A
%
% EXAMPLE
%   A = [4 2; 2 3];
%   e = pd2ellipse(A);
%   plot(e(1,:), e(2,:))

% Ivan Selesnick, selesi@nyu.edu, 2015

t = linspace(0, 2*pi, 100);

c = [cos(t); sin(t)];       % circle

[Q, D] = eig( A );

d = diag(D);

e = Q * diag(sqrt(d)) * c;   % ellipse 

