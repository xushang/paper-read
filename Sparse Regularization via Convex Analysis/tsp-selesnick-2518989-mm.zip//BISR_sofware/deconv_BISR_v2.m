function [x, num_iters, vopt] = deconv_BISR_v2(y, h, lam, gamma, pen)
% [x, num_iters, vopt] = deconv_BISR_v2(y, h, lam, gamma)
% Sparse deconvolution by bivariate sparse (non-convex) regularization.
% Version 2 : self-contained (no external function calls).
%
% Cost function:
%    F(x) = 0.5 sum(abs(y-conv(h,x)).^2) + lam/2 sum_m(psi(x(n-1),x(n)))
%
% INPUT
%   y - noisy data
%   h - filter impulse response
%   lam - regularization parameter
%   gamma - eigenvalues of 2x2 matrix
%   pen - penalty ( 'log' | 'atan' | 'rat' )
%
% OUTPUT
%   x - estimate of input signal
%   num_iters - number of iterations
%   vopt - verification of optimality
%              (x(n), vopt(n)) should lie on graph of sign function

% Algorithm: iterative thresholding (Forward Backward Splitting).
%
% Stopping condition:
% (relative change in x <= TOL_STOP) and (number of iterations >= 20)
% with TOL_STOP = 1e-4;

% Ivan Selesnick, selesi@nyu.edu, 2014
% Revised May 2015.

% Reference:
% Enhanced Sparsity by Non-Separable Regularization
% Ivan Selesnick and Ilker Bayram
% IEEE Transactions on Signal Processing, 2016

MIN_ITER = 10;
MAX_ITER = 100;
TOL_STOP = 1e-4;

soft = @(t, T) max(t - T, 0) + min(t + T, 0);

y = y(:);                                       % convert to column vector
N = length(y);
Nh = length(h);
L = N - Nh + 1;

H = sparse( convmtx(h(:), L) );
% h = h(:)';
% H = spdiags( h(ones(1,N),:), 0:-1:1-Nh, N, L);

rho = max(eig(H'*H));  

HTy = H' * y;               % H'*y
    
x = HTy;                    % initialization

a = gamma / lam;

mu = 1.9 / rho;             % mu : step size

lam_half = lam/2;
threshold_value = lam * mu;

ds_log = @(x) -x ./ (1 + abs(x));
ds_atan = @(x) - x .* (1 + abs(x) ) ./ (1 + abs(x).*(1 + abs(x)));

switch pen
    
    case 'log'
          ds = @(x, a) ds_log( a * x );

    case 'atan'
        ds = @(x, a) ds_atan( a * x);
        
    case 'rat'
        dphi = @(x, a) -(a/2)*x ./ ((a/2)*abs(x) + 1).^2  + sign(x)./((a/2)*abs(x) + 1);
        ds = @(x, a) dphi(x, a) - sign(x);
end


% ds = @(x, a) dphi(x, a) - sign(x);
a1 = a(1);
a2 = a(2);
alpha = (a1 + a2)/2;
r = (a1 - a2)/(a1 + a2);
upr = 1 + r;
umr = 1 - r;
dSdx1_1 = @(x1, x2) ds( x1 + r*x2, alpha);
% dSdx1_2 = @(x1, x2) r * ds( r * x1 + x2, alpha) + (1 - r) * ds( x1 , a1 );
% dSdx1_3 = @(x1, x2) r * ds( r * x1 + x2, alpha) + (1 + r) * ds( x1 , a2 );
dSdx1_4 = @(x1, x2) ds( x1 + r*x2, alpha);

% dSdx2_1 = @(x1, x2) r * ds( x1 + r*x2, alpha)+ (1 - r) * ds( x2 , a1 );
dSdx2_2 = @(x1, x2) ds( r * x1 + x2, alpha) ;
dSdx2_3 = @(x1, x2) ds( r * x1 + x2, alpha) ;
% dSdx2_4 = @(x1, x2) r * ds( x1 + r*x2, alpha) + (1 + r) * ds( x2 , a2 );


PRINT_INFO = false;
% PRINT_INFO = true;
delta_x = inf;
old_x = zeros(size(x));
iter = 0;


while (( delta_x > TOL_STOP ) || ( iter < MIN_ITER )) && (iter < MAX_ITER)
    
    iter = iter + 1;
    
    [s1, s2] = Sfun(x(1:end-1), x(2:end));    
    z = x - mu * ((H'*conv(h,x) - HTy) + lam_half * ([s1; 0] + [0; s2]));
    x = soft(z, threshold_value);
    
    delta_x = max(abs( x - old_x )) / max(abs(old_x));
    old_x = x;
    
    if PRINT_INFO
        fprintf('iteration %3d, delta_x = %.3e \n', iter, delta_x);
    end
    
    if false
        % Optimality scatter plot (to monitor convergence)
        [s1, s2] = Sfun(x(1:end-1), x(2:end));
        w = ([s1; 0] + [0; s2])/2;
        
        v = 1/lam * H'*(y - H*x) - w;
        
        figure(5)
        clf
        M = 1.5*max(abs(x));
        line([-M 0 0 M], [-1 -1 1 1], 'color', [1 1 1]*0.8, 'linewidth', 2)
        hold on
        plot(x, v, '.', 'markersize', 10)
        hold off
        xlim([-M M])
        ylim([-1.5 1.5])
        title(sprintf('Iteration %d', iter))
        drawnow
    end
    
end

if nargout > 3
    [s1, s2] = Sfun(x(1:end-1), x(2:end));
    w = ([s1; 0] + [0; s2])/2;
    vopt = 1/lam * H'*(y - H*x) - w;
end

num_iters = iter;

% nested function

    function [s1, s2] = Sfun(x1, x2)
        
        % [s1, s2] = Sfun(x1, x2)
        %
        % a : 2-element vector (positive, real) with a(1) > 0 a(2) > 0
        % x1, x2 : arrays of equal size
        
        % Areas 1-4
        k1 = x2 .* (x1 - x2) >= 0;
        k2 = x1 .* (x2 - x1) >= 0;
        k3 = -x1 .* (x2 + x1) >= 0;
        k4 = -x2 .* (x2 + x1) >= 0;
        
        s1 = nan(size(x1));
        s2 = nan(size(x1));

        s1(k1) = dSdx1_1(x1(k1), x2(k1));
        s2(k1) = r * s1(k1) + umr * ds( x2(k1), a1 );

        s2(k2) = dSdx2_2(x1(k2), x2(k2));
        s1(k2) = r * s2(k2) + umr * ds( x1(k2) , a1);

        s2(k3) = dSdx2_3(x1(k3), x2(k3));
        s1(k3) = r * s2(k3) + upr * ds( x1(k3) , a2);

        s1(k4) = dSdx1_4(x1(k4), x2(k4));
        s2(k4) = r * s1(k4) + upr * ds( x2(k4), a2 );
        
    end

end


