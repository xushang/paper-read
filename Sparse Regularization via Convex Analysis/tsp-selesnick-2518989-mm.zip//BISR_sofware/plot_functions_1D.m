
% plot_functions_1D


% pen = 'log';
pen = 'atan';

[phi, dphi, d2phi] = penalty(pen);

s = @(x, a) phi(x, a) - abs(x);
s1 = @(x, a) dphi(x, a) - sign(x);
s2 = @(x, a) d2phi(x, a);

x = 4 * (-50:50)/50;

a = 0.3;

%%

figure(1)
clf

subplot(2, 2, 1)
plot(x, abs(x), x, phi(x, a) )
legend('|t|', '\phi(t; a)');
xlabel('t')

subplot(2, 2, 2)
plot(x, s(x, a))
title('s(t; a) = \phi(t; a) - |t|');
xlabel('t')
ylim([-2 2])
grid

subplot(2, 2, 3)
plot(x, s1(x, a))
title('s''(t; a)');
xlabel('t')
grid

subplot(2, 2, 4)
plot(x, s2(x, a))
title('s''''(t; a)');
xlabel('t')
ylim([-1 1]*1.5*a)
set(gca, 'ytick', [-a 0 a])
text(0, -a, '-a');
grid

print -dpdf figures/functions_1D


%%

% Reference:
% Enhanced Sparsity by Non-Separable Regularization
% Ivan Selesnick and Ilker Bayram
% IEEE Transactions on Signal Processing, 2016
