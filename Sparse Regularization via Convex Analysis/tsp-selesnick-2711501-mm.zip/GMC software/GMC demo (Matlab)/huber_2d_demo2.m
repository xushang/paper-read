%% huber_2d_demo
% Show generalized Huber function in two-dimensions.
%
%  Ivan Selesnick
%  June 2016

%%

N = 27;
mx = 1.5;
x1 = linspace(-mx, mx, N);
x2 = linspace(-mx, mx, N);
[X1, X2] = meshgrid(x1, x2);

B = [1 0.5];

S = huber_2d(B, X1, X2);

figure(1)
clf
mesh(x1, x2, S, 'EdgeColor', 'black')
title('Generalized Huber function S_B(x)')
xlabel('x_1')
ylabel('x_2')
xlim([-mx mx])
ylim([-mx mx])
view([-20 20])
axis square
print -dpdf figures/huber_2d_demo2

%%

figure(2)
clf
mesh(x1, x2, abs(X1) + abs(X2) - S, 'EdgeColor', 'black')
title('GMC penalty \psi_B(x) = ||x||_1 - S_B(x)')
xlabel('x_1')
ylabel('x_2')
xlim([-mx mx])
ylim([-mx mx])
view([-20 20])
axis square
print -dpdf figures/huber_2d_demo2_GMC

