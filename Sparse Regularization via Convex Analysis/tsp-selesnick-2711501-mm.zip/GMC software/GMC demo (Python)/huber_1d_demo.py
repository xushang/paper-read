# huber_1d_demo

# Ivan Selesnick
# June 2016 (Matlab)
# May 2017 (Python)

import numpy as np
from matplotlib import pyplot as plt

# Define Huber function
def huber (t): return np.minimum( 0.5 * t**2, np.minimum( np.abs(t-1) + 0.5, np.abs(t+1) + 0.5 ))

# Plot Huber function
T = 3
t = np.linspace(-T, T, 101)

# Plot data
plt.figure(1, figsize = (7, 8))
plt.subplot(2, 1, 1)
plt.plot(t, huber(t))
plt.title('Huber function')
plt.ylim(0, 3)

# Plot MC penalty
plt.subplot(2, 1, 2)
plt.plot(t, abs(t), label = '|x|')
plt.plot(t, abs(t) - huber(t), label = 'MC penalty')
plt.title('MC penalty function');
plt.legend()

plt.savefig('figures/huber_1d_demo.pdf')

plt.show()
