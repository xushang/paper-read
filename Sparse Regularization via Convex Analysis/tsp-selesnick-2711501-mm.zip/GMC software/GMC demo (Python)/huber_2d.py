
import numpy as np

# Define 2D Generalized Huber function
def huber_2d(B, x0, x1):

    # # Define 1D Huber function
    def huber (t): return np.minimum( 0.5 * t**2, np.minimum( np.abs(t-1) + 0.5, np.abs(t+1) + 0.5 ))

    K = np.dot(np.transpose(B), B)

    Kx0 = K[0][0] * x0 + K[0][1] * x1
    Kx1 = K[1][0] * x0 + K[1][1] * x1

    d = np.linalg.det(K)
    print(d)

    # Initialization
    S = np.zeros(np.shape(x0)) + float('inf')

    if d < 1e-8:

        print('Matrix K is nearly singular')
        S = np.minimum(S, huber(Kx1)/K[1][1] )
        S = np.minimum(S, huber(Kx0)/K[0][0] )

    else:

        S = np.minimum(S, huber(Kx1)/K[1][1] + x0**2 * d / K[1][1] / 2.0 )
        S = np.minimum(S, huber(Kx0)/K[0][0] + x1**2 * d / K[0][0] / 2.0 )

        u = np.array([+1.0, +1.0])
        b = np.linalg.solve(K, u)
        S = np.minimum(S, np.abs( x0 - b[0]) + np.abs( x1 - b[1] ) + np.vdot(u, b)/2.0)

        u = np.array([-1.0, -1.0])
        b = np.linalg.solve(K, u)
        S = np.minimum(S, np.abs( x0 - b[0]) + np.abs( x1 - b[1] ) + np.vdot(u, b)/2.0)

        u = np.array([+1.0, -1.0])
        b = np.linalg.solve(K, u)
        S = np.minimum(S, np.abs( x0 - b[0]) + np.abs( x1 - b[1] ) + np.vdot(u, b)/2.0)

        u = np.array([-1.0, +1.0])
        b = np.linalg.solve(K, u)
        S = np.minimum(S, np.abs( x0 - b[0]) + np.abs( x1 - b[1] ) + np.vdot(u, b)/2.0)

    return S
