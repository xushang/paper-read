# GMC_demo
# 
# Demonstration of the generalized MC (GMC) penalty for sparse-regularized
# linear least squares. The GMC penalty is designed to maintain the convexity of
# the cost function to be minimized. In this example, sparse regularization
# is used to estimate a signal (with frequency-domain sparsity) from a
# noisy observation.
#  
# Demonstration software for the paper:
# I. Selesnick, 'Sparse Regularization via Convex Analysis'
# IEEE Transactions on Signal Processing, 2017.

# Ivan Selesnick
# May 2016 - MATLAB version
# May 2017 - Python version

# import numerical array library
import numpy as np

# import sparse-regularized least squares functions
from srls import srls_L1, srls_GMC

# import plotting library
from matplotlib import pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
pp = PdfPages('figures/GMC_demo_figures.pdf')

# Define root-mean-square-error (RMSE)
def rmse (x): return np.sqrt( np.mean( np.abs(x)**2 ) )

# Create data (sinusoids in white noise)
M = 100    # M: signal length
N = 256    # N: transform length

f1 = 0.1
f2 = 0.22
m = np.arange(M)
s = 2.0*np.cos(2.0*np.pi*f1*m) + np.sin(2.0*np.pi*f2*m);    # s : true signal

sigma = 1.0           	# sigma : noise standard deviation
w = np.random.randn(M)	# w : white Gaussian noise
y = s + sigma * w   	# y : signal plus noise

# Plot data
plt.figure(1)
plt.subplot(2, 1, 1)
plt.plot(m, s)
plt.title('Noise-free data')

plt.subplot(2, 1, 2)
plt.plot(m, y)
plt.title('Noisy data')
pp.savefig()

# Define linear operator A (inverse DFT)
# Matrix A is of size 100 x 256 and satisfies A A' = I
def truncate (x): return x[:M]
def AH (x): return np.fft.fft(x, n = N) / np.sqrt(N)
def A (x): return truncate(np.fft.ifft(x) * np.sqrt(N))

# Verify perfect reconstruction, that is, A(AH) is identity
v = np.random.randn(M)
print('Reconstruction error is %e' % rmse(v - A(AH(v))))

# Sparse regulared least squares using L1 norm 
lam_L1 = 1.0
c_L1 = srls_L1(y, A, AH, 1, lam_L1)
x_L1 = A(c_L1)

# Sparse regulared least squares using GMC
lam_GMC = 2.0
gamma = 0.8
c_GMC = srls_GMC(y, A, AH, 1, lam_GMC, gamma)
x_GMC = A(c_GMC)

# Plot sparse coefficients
plt.figure(2)
plt.subplot(2, 1, 1)
plt.plot(np.abs(c_L1))
plt.title('Sparse coefficients (L1 norm)')
plt.xlim(0, N)
plt.subplot(2, 1, 2)
plt.plot(np.abs(c_GMC))
plt.title('Sparse coefficients (GMC)')
plt.xlim(0, N)
pp.savefig()

# Plot sparse coefficients (on same axis)
plt.figure(3)
plt.plot(np.abs(c_GMC), 'x', label = 'GMC')
plt.plot(np.abs(c_L1), 'o', markerfacecolor = 'none' , label = 'L1 norm')
plt.legend()
plt.title('Sparse coefficients')
plt.xlim(0, 0.5*N)
pp.savefig()

# Plot denoised signal
plt.figure(4)
plt.plot(np.real(x_GMC), label = 'GMC')
plt.plot(np.real(x_L1), label = 'L1 norm')
plt.title('Denoised signals')
plt.legend()
pp.savefig()
pp.close()

print(' RMSE (L1 ) = %f' % rmse(x_L1 - s))
print(' RMSE (GMC) = %f' % rmse(x_GMC - s))

plt.show()

