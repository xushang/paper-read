# huber_2d_demo2
# Plot 2D generalized Huber function

# Ivan Selesnick
# June 2016 (Matlab)
# May 2017 (Python)

import numpy as np
from matplotlib import pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

import huber_2d 

N = 27.0
mx = 1.5
x1 = np.linspace(-mx, mx, N)
x2 = np.linspace(-mx, mx, N)
[X0, X1] = np.meshgrid(x1, x2)

B = [[1, 0.5]]

S = huber_2d.huber_2d(B, X0, X1)

# Plot generalized Huber function
fig1 = plt.figure()
ax1 = Axes3D(fig1)
ax1.plot_surface(X0, X1, S, rstride = 1, cstride = 1, cmap = 'hot')
ax1.view_init(20, 70)
plt.title('Generalized Huber function')
plt.savefig('figures/huber_2d_demo2.pdf')

# Plot GMC penalty
fig2 = plt.figure()
ax2 = Axes3D(fig2)
ax2.plot_surface(X0, X1, np.abs(X0) + np.abs(X1) - S, rstride = 1, cstride = 1, cmap = 'hot')
ax2.view_init(20, 70)
plt.title('GMC penalty function')
plt.savefig('figures/huber_2d_demo2_GMC.pdf')

plt.show()
