function x = tvd_L1(y, lam)

% x = tvd_L1(y, lam)
%
% Total variation signal denoising using the L1 norm
% (i.e., classical TV denoising)
%
% INPUT
%   x : data (one-dimensional array)
%   lam : regularization parameter, lam > 0
%
% OUTPUT
%   x : denoised data

x = TV_Condat_v2(y, lam);

% The program TV_Condat_v2 for the fast implementation of
% classical TV denoising is by Laurent Condat:
% https://lcondat.github.io
% https://lcondat.github.io/download/TV_Condat_v2.m



