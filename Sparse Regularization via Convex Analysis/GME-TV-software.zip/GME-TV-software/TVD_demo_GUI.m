function TVD_demo_GUI
% Graphical user interface (GUI) for GME-TV denoising demo

y = load('blocks_noisy.txt');   % load data
sigma = 0.5;

x_clean = load('blocks.txt');   % load data

N = length(y);
n = 1:N;

lam = 2.5;       % lam : positive smoothing parameter
K = 10;        % K : length of high-pass filter impulse response
Nit = 10;      % Nit : Number of algorithm iterations

x = tvd_gme(y, lam, K, Nit);     % GME-TV denoising

fig1 = figure(1);
clf
noise_line = line(n, y, 'marker', '.', 'linestyle', 'none', 'markersize', 10, 'color', [1 1 1]*0.5);
% line(n, x_clean, 'linewidth', 2, 'color', 'red');
denoised_line = line(n, x, 'linewidth', 2, 'color', 'black');
legend('Noisy data', 'Denoised')
% legend('Noisy','Clean','Denoised')
title( sprintf('TV denoising. lambda = %.3f K = %d', lam, K) )
fig1.Units = 'Normalized';
ax = gca;
% ax.Units
ax.Position = [0.1 0.3 0.8 0.65];
xlim([0 N])
ylim([-3 6])

drawnow;

panel_main = uipanel(fig1, ...% 'Title','Parameters',...
    'Position',[.1 .0 .8 .25]);

% position [left bottom width height]

panel_alg = uipanel(panel_main, ...% 'Title','Algorithm',...
    'Position',[0 .0 .3 1]);

panel_params = uipanel(panel_main, ..., %'Title','Parameters',...
    'Position',[0.3 .0 .7 1]);

Alg_type_list = {'Classic TV', 'GME-TV'};

alg_handle = uicontrol(panel_alg, ...
    'Value', 2, ...
    'Style','popupmenu', ...
    'units', 'normalized', ...
    'Position', [0.0 0.5 1.0 0.4], ...
    'String', Alg_type_list , ...
    'Callback', @update_plot);

noise_button = uicontrol(panel_alg, ...
    'Style','pushbutton', ...
    'units', 'normalized', ...
    'Position', [0.0 0.1 1.0 0.4], ...
    'String', 'New noise', ...
    'Callback', @new_noise);

slider_lam = uicontrol(panel_params , ...
    'Style', 'slider', ...
    'Min', 0.0, 'Max', 10, ...
    'Value', lam, ...
    'SliderStep', [0.01 0.05], ...
    'units', 'normalized', ...
    'Position', [0.2 0.5 0.6 0.3], ...
    'Callback',  @update_plot );

% label: lambda
uicontrol(panel_params , ...
    'Style','Text', ...
    'units', 'normalized', ...
    'Position', [0.0 0.5 0.2 0.3], ...
    'String', 'lambda')

% position [left bottom width height]

slider_K = uicontrol(panel_params , ...
    'Style', 'slider', ...
    'Min', 0, 'Max', 20, ...
    'Value', K, ...
    'SliderStep', [1 1]/20, ...
    'units', 'normalized', ...
    'Position', [0.2 0.1 0.6 0.3], ...
    'Callback',  @update_plot );

% label: K
uicontrol(panel_params , ...
    'Style','Text', ...
    'units', 'normalized', ...
    'Position', [0.0 0.1 0.2 0.3], ...
    'String', 'K')

% callback functions

    function new_noise(hObject, eventdata)
        
        x_clean = load('blocks.txt');   % load data
        sigma = 0.5;
        y = x_clean + sigma * randn(size(x_clean));
        set(noise_line, 'ydata',  y);        % Update data in figure
        update_plot
        
    end

    function update_plot(hObject, eventdata)
        
        lam = slider_lam.Value;
        Type_of_TV_Regularization = Alg_type_list{alg_handle.Value};
        K = round(slider_K.Value);
        
        switch Type_of_TV_Regularization
            case 'Classic TV'
                x = TV_Condat_v2(y, lam);   % m-file
                title( sprintf('TV denoising. lambda = %.3f', lam) )
            case 'GME-TV'
                x = tvd_gme(y, lam, K, Nit);
                title( sprintf('TV denoising. lambda = %.3f K = %d', lam, K) )
        end
        set(denoised_line, 'ydata',  x);        % Update data in figure
    end

end

