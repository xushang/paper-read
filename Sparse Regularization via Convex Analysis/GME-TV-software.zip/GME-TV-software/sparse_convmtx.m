function A = sparse_convmtx(h, n)
% A = sparse_convmtx(h, n)
% h : row vector

M = length(h);
hh = h(ones(n,1), :);
A = spdiags(hh, 0:M-1, n, n+M-1);
