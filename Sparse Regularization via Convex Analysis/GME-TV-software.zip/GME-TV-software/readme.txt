Total Variation Denoising using the Generalized Moreau Envelope

Software to supplement the paper: 
'Non-convex total variation regularization for convex denoising of signals'
Ivan Selesnick, Alessandro Lanza, Serena Morigi, and Fiorella Sgallari
Journal of Mathematical Imaging and Vision, 2020
DOI: 10.1007/s10851-019-00937-5

Contact info:
Ivan Selesnick (1) selesi@nyu.edu
B Fiorella Sgallari (2) fiorella.sgallari@unibo.it
Alessandro Lanza (2) alessandro.lanza2@unibo.it
Serena Morigi (2) serena.morigi@unibo.it

(1) Department of Electrical and Computer Engineering, New York University, Brooklyn, New York, USA
(2) Department of Mathematics, University of Bologna, Bologna, Italy

The enclosed software implements and illustrates GME-TV denoising (denoising using the generalized Moreau envelop) of piecewise constant one-dimensional signals. 

List of programs:
demo.m			Demonstration programtvd_gme.m		GME-TV denoisingtvd_L1.m			Classical TV denoising
sparse_convmtx.m	sparse convolution matrix

The algorithm for GME-TV denoising uses classical TV denoising as an ingredient. The enclosed software uses the program TV_Condat_v2 by Laurent Condat for the classical TV denoising step. 
https://lcondat.github.io
https://lcondat.github.io/download/TV_Condat_v2.m

The blocks signal is from WaveLab
http://statweb.stanford.edu/~wavelab/
