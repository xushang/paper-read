%% demo
%
% Demo: GME-TV denoising and Classical TV denoising
%
% Reference: 
% 'Non-convex total variation regularization for convex denoising of signals'
% I. Selesnick, A. Lanza, S. Morigi, and F. Sgallari
% J. Math. Imaging and Vision, 2020. DOI: 10.1007/s10851-019-00937-5

%% Load data

clear

y = load('blocks_noisy.txt');   % load data
sigma = 0.5;

x_clean = load('blocks.txt');   % load data

N = length(y);
n = 1:N;

figure(1)
clf
plot(n, y, 'color', 'black', 'linewidth', 1)
title('Noisy signal');
ax = [0 length(y) -3 6];
axis(ax)

print -dpdf demo-noisy

%% GME-TV denoising

lam = 2.5;     % lam : positive smoothing parameter
K = 10;        % K : length of high-pass filter impulse response (positive integer)

x_gme = tvd_gme(y, lam, K);

GRAY = 0.7 * [1 1 1];
figure(1)
clf
plot(n, y, 'linewidth', 2, 'color', GRAY);
line(n, x_gme, 'color', 'black', 'linewidth', 1)
legend('Noisy signal', 'Denoised signal', 'Location', 'NorthWest')
title('GME-TV denoising')
axis(ax)

print -dpdf demo-TVD-GME

% To monitor and verify convergence, use the 'plots' flag.
% x_gme = tvd_gme(y, lam, K, 'plots');
% As the algorithm converges, the relative error should go to 
% zero, and the points in the scatter plot should 
% go to the graph of the sign function.


%% Classical TV denoising

lam_L1 = 0.9;
x_L1 = tvd_L1(y, lam_L1);
    
figure(1)
clf
plot(n, y, 'linewidth', 2, 'color', GRAY);
line(n, x_L1, 'color', 'black', 'linewidth', 1)
legend('Noisy signal', 'Denoised signal', 'Location', 'NorthWest')
title('Classical TV denoising')
axis(ax)

print -dpdf demo-TVD-Classic
